const express = require('express');
const cors = require('cors');
const https = require('https');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Shopify proxy
app.use('/shopify', (req, res) => {
  const shopUrl = req.headers['x-shop-url'];
  const token = req.headers['x-shopify-token'];
  if (!shopUrl || !token) return res.status(400).json({ error: 'Missing shop URL or token' });

  const path = req.url;
  const options = {
    hostname: shopUrl,
    path: path,
    method: req.method,
    headers: {
      'X-Shopify-Access-Token': token,
      'Content-Type': 'application/json'
    }
  };

  const proxyReq = https.request(options, (proxyRes) => {
    res.status(proxyRes.statusCode);
    Object.entries(proxyRes.headers).forEach(([k, v]) => {
      if (k.toLowerCase() !== 'transfer-encoding') res.setHeader(k, v);
    });
    proxyRes.pipe(res);
  });

  proxyReq.on('error', (e) => res.status(500).json({ error: e.message }));
  if (req.body) proxyReq.write(JSON.stringify(req.body));
  proxyReq.end();
});

// Meta proxy
app.use('/meta', (req, res) => {
  const path = req.url;
  const options = {
    hostname: 'graph.facebook.com',
    path: path,
    method: req.method,
    headers: { 'Content-Type': 'application/json' }
  };

  const proxyReq = https.request(options, (proxyRes) => {
    res.status(proxyRes.statusCode);
    proxyRes.pipe(res);
  });

  proxyReq.on('error', (e) => res.status(500).json({ error: e.message }));
  proxyReq.end();
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => console.log(`Profit Analytics server running on port ${PORT}`));
